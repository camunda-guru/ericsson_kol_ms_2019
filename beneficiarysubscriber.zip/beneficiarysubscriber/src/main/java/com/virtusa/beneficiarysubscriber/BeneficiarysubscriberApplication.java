package com.virtusa.beneficiarysubscriber;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeneficiarysubscriberApplication {

	public static void main(String[] args) {
		SpringApplication.run(BeneficiarysubscriberApplication.class, args);
	}

}
